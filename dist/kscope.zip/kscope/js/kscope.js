(function localScope() {apex.jQuery(document).ready(function() {

  // Make row clickable
  $('.t-IRR-region').customReport();

  // Set defaultShortcuts
  kscope.keyboardShortcuts.defaultShortcuts();

});
})();